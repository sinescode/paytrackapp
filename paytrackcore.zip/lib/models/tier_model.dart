// lib/models/tier_model.dart

import 'dart:convert';

// ── Tier Definition ───────────────────────────────────────────────────────────
//
// JSON (inside config.tier_definitions):
// { "id": 3, "name": "PR 3", "min_ok": 1000, "max_ok": 99999, "price_per_ok": 4.1 }

class TierDefinition {
  final int id;
  final String name;
  final int minOk;
  final int maxOk;
  final double pricePerOk;

  TierDefinition({
    required this.id,
    required this.name,
    required this.minOk,
    required this.maxOk,
    required this.pricePerOk,
  });

  factory TierDefinition.fromJson(Map<String, dynamic> j) => TierDefinition(
        id: (j['id'] as num).toInt(),
        name: j['name']?.toString() ?? '',
        minOk: (j['min_ok'] as num).toInt(),
        maxOk: (j['max_ok'] as num).toInt(),
        pricePerOk: (j['price_per_ok'] as num).toDouble(),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'min_ok': minOk,
        'max_ok': maxOk,
        'price_per_ok': pricePerOk,
      };

  TierDefinition copyWith({
    int? id,
    String? name,
    int? minOk,
    int? maxOk,
    double? pricePerOk,
  }) =>
      TierDefinition(
        id: id ?? this.id,
        name: name ?? this.name,
        minOk: minOk ?? this.minOk,
        maxOk: maxOk ?? this.maxOk,
        pricePerOk: pricePerOk ?? this.pricePerOk,
      );

  @override
  String toString() =>
      'TierDefinition(id:$id, name:$name, min:$minOk, max:$maxOk, price:$pricePerOk)';
}

// ── UserTier — resolved, lightweight view used by the rest of the app ─────────
//
// NOT stored directly in JSON. Built at runtime by resolving the int ID list
// in user_tiers against tier_definitions. Kept for backward-compat with
// CardGenerator, send screens, etc.

class UserTier {
  final int minOk;
  final int maxOk;
  final double pricePerOk;

  UserTier({
    required this.minOk,
    required this.maxOk,
    required this.pricePerOk,
  });

  factory UserTier.fromJson(Map<String, dynamic> j) => UserTier(
        minOk: (j['min_ok'] as num).toInt(),
        maxOk: (j['max_ok'] as num).toInt(),
        pricePerOk: (j['price_per_ok'] as num).toDouble(),
      );

  Map<String, dynamic> toJson() => {
        'min_ok': minOk,
        'max_ok': maxOk,
        'price_per_ok': pricePerOk,
      };
}

// ── AppConfig ─────────────────────────────────────────────────────────────────
//
// Full on-disk JSON shape:
// {
//   "config": {
//     "tier_definitions": [
//       { "id": 3, "name": "PR 3", "min_ok": 1000, "max_ok": 99999, "price_per_ok": 4.1 },
//       ...
//     ],
//     "user_tiers": {
//       "5247038532": [1, 2, 3],   ← ordered list of tier definition IDs
//       ...
//     },
//     "custom_names": { "8274064877": "Sahriya", ... }
//   },
//   "balances": { "8274064877": -924.7, ... }
// }
//
// bot_token is kept outside the exported JSON (stored only in SharedPreferences)
// so it is never accidentally written to a plain file. It can optionally appear
// at the root level for manual imports.

class AppConfig {
  /// Telegram bot token — never exported to Config.json, only in prefs.
  final String botToken;

  /// All known tier definitions, each with a unique [id].
  final List<TierDefinition> tierDefinitions;

  /// Per-user ordered list of tier IDs  (mirrors JSON user_tiers exactly).
  final Map<String, List<int>> userTierIds;

  final Map<String, String> customNames;

  /// Per-user running balance (negative = owed to user / credit).
  final Map<String, double> balances;

  AppConfig({
    this.botToken = '',
    List<TierDefinition>? tierDefinitions,
    Map<String, List<int>>? userTierIds,
    Map<String, String>? customNames,
    Map<String, double>? balances,
  })  : tierDefinitions = tierDefinitions ?? [],
        userTierIds = userTierIds ?? {},
        customNames = customNames ?? {},
        balances = balances ?? {};

  // ── Resolve helpers ───────────────────────────────────────────────────────

  /// id → TierDefinition lookup map (rebuilt each call — fast enough).
  Map<int, TierDefinition> get _tierById =>
      {for (final t in tierDefinitions) t.id: t};

  /// Returns the resolved [TierDefinition] objects assigned to [userId].
  /// Silently skips any ID that no longer exists in tierDefinitions.
  List<TierDefinition> tiersForUser(String userId) {
    final byId = _tierById;
    return (userTierIds[userId] ?? [])
        .map((id) => byId[id])
        .whereType<TierDefinition>()
        .toList();
  }

  /// Convenience: resolved UserTier list for one user (used by legacy callers).
  List<UserTier> userTiersForUser(String userId) => tiersForUser(userId)
      .map((d) => UserTier(
            minOk: d.minOk,
            maxOk: d.maxOk,
            pricePerOk: d.pricePerOk,
          ))
      .toList();

  /// Convenience: resolved map of all users → UserTier list.
  Map<String, List<UserTier>> get userTiers => {
        for (final uid in userTierIds.keys) uid: userTiersForUser(uid),
      };

  // ── Serialisation ─────────────────────────────────────────────────────────

  /// Parse the full on-disk JSON.
  /// Accepts both the wrapped format  { "config": {...}, "balances": {...} }
  /// and a flat/legacy format          { "tier_definitions": [...], ... }.
  factory AppConfig.fromJson(Map<String, dynamic> root) {
    final bool wrapped = root.containsKey('config');
    final Map<String, dynamic> cfg =
        wrapped ? (root['config'] as Map<String, dynamic>) : root;

    // tier_definitions  →  List<TierDefinition>
    final tierDefs = <TierDefinition>[];
    for (final raw in (cfg['tier_definitions'] as List? ?? [])) {
      tierDefs.add(TierDefinition.fromJson(raw as Map<String, dynamic>));
    }

    // user_tiers  →  Map<userId, List<tierId>>
    // Values in JSON are List<int>  e.g.  "5247038532": [1, 2, 3]
    final userTierIds = <String, List<int>>{};
    (cfg['user_tiers'] as Map<String, dynamic>? ?? {})
        .forEach((uid, rawList) {
      userTierIds[uid] =
          (rawList as List).map((v) => (v as num).toInt()).toList();
    });

    // custom_names
    final customNames = <String, String>{};
    (cfg['custom_names'] as Map<String, dynamic>? ?? {})
        .forEach((k, v) => customNames[k] = v.toString());

    // balances  (top-level key in the wrapped format)
    final balances = <String, double>{};
    (root['balances'] as Map<String, dynamic>? ?? {})
        .forEach((k, v) => balances[k] = (v as num).toDouble());

    // bot_token (optional, root level — never written back out)
    final botToken = root['bot_token'] as String? ?? '';

    return AppConfig(
      botToken: botToken,
      tierDefinitions: tierDefs,
      userTierIds: userTierIds,
      customNames: customNames,
      balances: balances,
    );
  }

  factory AppConfig.fromJsonString(String src) =>
      AppConfig.fromJson(jsonDecode(src) as Map<String, dynamic>);

  /// Serialise back to the same wrapped format — round-trips are lossless.
  /// bot_token is intentionally excluded from the exported file.
  Map<String, dynamic> toJson() => {
        'config': {
          'tier_definitions':
              tierDefinitions.map((t) => t.toJson()).toList(),
          'user_tiers':
              userTierIds.map((uid, ids) => MapEntry(uid, ids)),
          'custom_names': customNames,
        },
        'balances': balances,
      };

  String toJsonString() =>
      const JsonEncoder.withIndent('  ').convert(toJson());

  // ── Immutable copy ─────────────────────────────────────────────────────────

  AppConfig copyWith({
    String? botToken,
    List<TierDefinition>? tierDefinitions,
    Map<String, List<int>>? userTierIds,
    Map<String, String>? customNames,
    Map<String, double>? balances,
  }) =>
      AppConfig(
        botToken: botToken ?? this.botToken,
        tierDefinitions:
            tierDefinitions ?? tierDefinitions ?? List.from(this.tierDefinitions),
        userTierIds: userTierIds ??
            {
              for (final e in this.userTierIds.entries)
                e.key: List<int>.from(e.value)
            },
        customNames: customNames ?? Map.from(this.customNames),
        balances: balances ?? Map.from(this.balances),
      );

  // ── Tier mutation helpers (used by SettingsScreen) ────────────────────────

  /// Next safe ID for a new tier definition.
  int get nextTierId => tierDefinitions.isEmpty
      ? 1
      : tierDefinitions.map((t) => t.id).reduce((a, b) => a > b ? a : b) + 1;

  /// Upsert: replace existing def with same id, or append new one.
  AppConfig upsertTier(TierDefinition def) {
    final exists = tierDefinitions.any((t) => t.id == def.id);
    final updated = exists
        ? [for (final t in tierDefinitions) t.id == def.id ? def : t]
        : [...tierDefinitions, def];
    return copyWith(tierDefinitions: updated);
  }

  /// Remove tier by id and strip it from every user assignment.
  AppConfig removeTier(int tierId) {
    return copyWith(
      tierDefinitions: tierDefinitions.where((t) => t.id != tierId).toList(),
      userTierIds: userTierIds.map(
        (uid, ids) =>
            MapEntry(uid, ids.where((id) => id != tierId).toList()),
      ),
    );
  }
}
